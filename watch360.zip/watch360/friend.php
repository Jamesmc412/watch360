<?php
include 'config.php';  // Include the database connection

// Function to send a friend request
function sendFriendRequest($userId, $friendId) {
    global $pdo;

    // Check if the friend request already exists
    $sql = "SELECT * FROM friendships WHERE user_id = :userId AND friend_id = :friendId";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['userId' => $userId, 'friendId' => $friendId]);

    if ($stmt->rowCount() == 0) {
        // Insert the new friend request with a 'pending' status
        $sql = "INSERT INTO friendships (user_id, friend_id, status) VALUES (:userId, :friendId, 'pending')";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['userId' => $userId, 'friendId' => $friendId]);

        return "Friend request sent!";
    } else {
        return "You have already sent a friend request to this user.";
    }
}

// Function to accept a friend request
function acceptFriendRequest($userId, $friendId) {
    global $pdo;

    // Update the status of the friend request to 'accepted'
    $sql = "UPDATE friendships SET status = 'accepted' WHERE user_id = :friendId AND friend_id = :userId AND status = 'pending'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['friendId' => $friendId, 'userId' => $userId]);

    if ($stmt->rowCount() > 0) {
        return "Friend request accepted!";
    } else {
        return "No pending friend request found.";
    }
}

// Function to reject or block a friend request
function rejectOrBlockFriend($userId, $friendId, $block = false) {
    global $pdo;

    $status = $block ? 'blocked' : 'rejected';

    // Update the status of the friend request to 'rejected' or 'blocked'
    $sql = "UPDATE friendships SET status = :status WHERE user_id = :friendId AND friend_id = :userId AND status = 'pending'";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['status' => $status, 'friendId' => $friendId, 'userId' => $userId]);

    if ($stmt->rowCount() > 0) {
        return "Friend request " . ($block ? "blocked" : "rejected") . "!";
    } else {
        return "No pending friend request found.";
    }
}

// Function to check the friendship status between two users
function checkFriendshipStatus($userId, $friendId) {
    global $pdo;

    $sql = "SELECT status FROM friendships WHERE (user_id = :userId AND friend_id = :friendId) OR (user_id = :friendId AND friend_id = :userId)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['userId' => $userId, 'friendId' => $friendId]);

    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['status'];
    } else {
        return "No relationship exists.";
    }
}
?>
