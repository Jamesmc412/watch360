<?php
session_start();
include 'friend.php';  // This is the file containing the functions above

// Assume the logged-in user ID is stored in a session
$loggedInUserId = $_SESSION['user_id'];

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $friendId = $_POST['friend_id'];

    switch ($action) {
        case 'send_request':
            echo sendFriendRequest($loggedInUserId, $friendId);
            break;
        case 'accept_request':
            echo acceptFriendRequest($loggedInUserId, $friendId);
            break;
        case 'reject_request':
            echo rejectOrBlockFriend($loggedInUserId, $friendId);
            break;
        case 'block_user':
            echo rejectOrBlockFriend($loggedInUserId, $friendId, true);
            break;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Friendship Management</title>
</head>
<body>
    <h2>Friendship Management</h2>
    
    <!-- Form to send a friend request -->
    <form action="friendship.php" method="post">
        <input type="hidden" name="action" value="send_request">
        <input type="text" name="friend_id" placeholder="Friend ID" required>
        <button type="submit">Send Friend Request</button>
    </form>

    <!-- Form to accept a friend request -->
    <form action="friendship.php" method="post">
        <input type="hidden" name="action" value="accept_request">
        <input type="text" name="friend_id" placeholder="Friend ID" required>
        <button type="submit">Accept Friend Request</button>
    </form>

    <!-- Form to reject a friend request -->
    <form action="friendship.php" method="post">
        <input type="hidden" name="action" value="reject_request">
        <input type="text" name="friend_id" placeholder="Friend ID" required>
        <button type="submit">Reject Friend Request</button>
    </form>

    <!-- Form to block a user -->
    <form action="friendship.php" method="post">
        <input type="hidden" name="action" value="block_user">
        <input type="text" name="friend_id" placeholder="Friend ID" required>
        <button type="submit">Block User</button>
    </form>
</body>
</html>
